const express = require('express')
const app = express();
const bodyParser = require("body-parser")
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
const dbconnect = require("./connection/conn");
const cors = require("cors");


dbconnect();

const AddEmployee = require('./route/employeeRoute')
const getEmployee = require('./route/employeeRoute')
const getSingleEmpolyee = require('./route/employeeRoute')
const updateEmployee = require('./route/employeeRoute')


app.use(cors());
app.use(cors({ origin: "*" }));
app.use(function (req, res, next) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE,PATCH");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    res.setHeader("Access-Control-Allow-Credentials", true);
    next();
});




app.use('/api/v1', AddEmployee)
app.use('/api/v1', getEmployee)
app.use('/api/v1', getSingleEmpolyee)
app.use('/api/v1', updateEmployee)





app.listen(3210, () => {
    console.log('server created')
})