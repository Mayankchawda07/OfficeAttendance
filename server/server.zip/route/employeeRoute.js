const express = require('express')
const { addEmployee, getEmployee, getSingleEmpolyee, updateEmployee } = require('../controller/employrrController')
const adminRoutes = express.Router();


adminRoutes.post('/AddEmployee', addEmployee)
adminRoutes.get('/getEmployee', getEmployee)
adminRoutes.get('/getEmployeeByid/:id', getSingleEmpolyee)
adminRoutes.put('/updateEmployeeByid/:id', updateEmployee)




module.exports = adminRoutes