const mongoose = require('mongoose')
const EmployeeSchema = new mongoose.Schema({
    name: {
        type: String
    },
    email: {
        type: String
    },
    password: {
        type: String
    },
    phone: {
        type: Number
    },
    leaves: {
        type: Number
    }
}, { timestamps: true });

const employee = mongoose.model('employee', EmployeeSchema)
module.exports = employee;