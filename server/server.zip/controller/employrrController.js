const employee = require('../modals/employeeModal')
const bcrypt = require("bcrypt");

exports.addEmployee = async (req, res) => {
    const { name, email, phone } = req.body;

    const salt = await bcrypt.genSalt(10);
    const password = await bcrypt.hash(email, salt);

    if (!name || !email || !phone) {
        return res.status(422).json({ error: 'Please filled all fields properly' })
    }
    try {
        const employeeExist = await employee.findOne({ email: email });
        if (employeeExist) {
            return res.status(422).json({ error: "Employee is already exist" });
        }
        else {
            const person = await employee.create({ name, email, phone, password })

            res.status(201).json({ message: "Employee register successfuly" });
        }
    } catch (error) {
        console.log(error)
    }
}

exports.updateEmployee = async (req, res) => {
    const { name, email, phone, password } = req.body;
    const getusername = await employee.findById(req.params.id);
    const na = getusername.name;
    const data = await employee.findByIdAndUpdate(
      req.params.id,
      { name, email, phone, password },
      { new: true }
    );
    res.status(200).json({
      status: "success",
      message: " Data Found",
      id:req.params.id
     // data: data,
    });
  };

exports.getEmployee = async (req, res) => {
    const datas = await employee.find();
    res.status(200).json({
        status: "success",
        message: "Employees found successfully",
        data: datas,
    });
};

exports.getSingleEmpolyee = async (req, res) => {
    try {
         const userFound = await employee.findById(req.params.id);
        res.status(200).json({
            status: "success",
            message: " Data Found",
             data: userFound,
        });
    } catch (error) {
        next(appErr(error.message));
    }
};

