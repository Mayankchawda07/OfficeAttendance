import React from 'react'
import { Link } from 'react-router-dom'

const Sidenav = () => {
    return (
        <>
            <nav className="sidebar sidebar-offcanvas clr" id="sidebar">
                <ul className="nav">
                    <li className="nav-item">
                        <Link className="nav-link" to="/dashboard">
                        <i className="icon-grid menu-icon"></i>
                            <span className="menu-title">Dashboard</span>
                        </Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="/employee">
                            <i className="icon-cog menu-icon"></i>
                            <span className="menu-title">Employee</span>
                        </Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="/attendance">
                            <i className="icon-image menu-icon"></i>
                            <span className="menu-title">Attendance</span>
                        </Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="/payroll">
                            <i className="icon-paper menu-icon"></i>
                            <span className="menu-title">Payroll</span>
                        </Link>
                    </li>
                </ul>
            </nav>
        </>
    )
}

export default Sidenav