import React from 'react'
import { Link } from 'react-router-dom'

const Login = () => {
    return (
        <>
            <div className="container-scroller">
                <div className="container-fluid page-body-wrapper full-page-wrapper">
                    <div className="content-wrapper d-flex align-items-center auth px-0">
                        <div className="row w-100 mx-0">
                            <div className="col-lg-4 mx-auto">
                                <div className="auth-form-light text-left py-5 px-4 px-sm-5">
                                    <div className="brand-logo">
                                        {/* <img src={require('../Images/imgpsh_fullsize_anim__1_-removebg-preview.png')} alt="LOGO" className='logo loginlogo' /> */}
                                        LOGO
                                    </div>
                                    {/* <h6 className="font-weight-light">Sign in to continue.</h6> */}
                                    <form className="pt-3" >
                                        <div className="form-group">
                                            <input type="email" className="form-control form-control-lg" id="exampleInputEmail1" placeholder="Username" name='email' />
                                        </div>
                                        <div className="form-group">
                                            <input type="password" className="form-control form-control-lg" id="exampleInputPassword1" placeholder="Password" name='password' />
                                        </div>
                                        <div className="mt-3">
                                            <Link to='/dashboard' className="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn">SIGN IN</Link>
                                        </div>
                                        <div className="my-2 d-flex justify-content-between align-items-center">
                                            <div className="form-check">
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </>
    )
}

export default Login