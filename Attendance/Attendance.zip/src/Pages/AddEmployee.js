import React, { useState } from 'react'
import Header from '../Template/Header'
import Sidenav from '../Template/Sidenav'
import { useNavigate } from 'react-router-dom'


const AddEmployee = () => {
    const navigate = useNavigate();

    const [data, setData] = useState({ name: '', phone: '', email: '' });

    const handelChange = (e) => {
        const name = e.target.name;
        let value = e.target.value;
        setData({ ...data, [name]: value });
    };

    const Submit = async (e) => {
        e.preventDefault();
        const { name, phone, email } = data;
        if (!name || !phone || !email) {
            return alert('Please fill all the field prperly')
        }
        const fetchdata = fetch(`http://localhost:3210/api/v1/AddEmployee`,
            {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ name: name, phone: phone, email: email }),
            });
        const response = await fetchdata;
        const responseData = await response.json();
        if (response.status === 201) {
            navigate("/employee");
        } else {
            console.error("Error:", responseData);
            alert("Error:", responseData);
        }
    };

    return (
        <>
            <div class="container-scroller">
                < Header />
                <div class="container-fluid page-body-wrapper">
                    <Sidenav />
                    <div class="main-panel">
                        <div class="content-wrapper">
                            <div class="row">
                                <div class="col-md-12 grid-margin">
                                    <div class="card">
                                        <div class="card-body">
                                            <h4 class="card-title">Add Employee</h4>
                                            <p class="card-description"></p>
                                            <div className="row">
                                                <div class="form-group col-md-6">
                                                    <label for="exampleInputUsername1">Employee Name</label>
                                                    <input type="text" class="form-control" name='name' placeholder='Enter Employee Name' value={data.name} onChange={handelChange} />
                                                </div>

                                                <div class="form-group col-md-6">
                                                    <label for="exampleInputPassword1">Phone</label>
                                                    <input type="number" class="form-control" min="0" name='phone' placeholder='Enter phone No.' value={data.phone} onChange={handelChange} />
                                                </div>

                                                <div class="form-group col-md-6">
                                                    <label for="exampleInputPassword1">Email</label>
                                                    <input type="email" class="form-control" min="0" name='email' placeholder='Enter email' value={data.email} onChange={handelChange} />
                                                </div>
                                            </div>
                                            <button type="submit" class="btn btn-primary me-2" onClick={Submit} >Submit</button>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default AddEmployee